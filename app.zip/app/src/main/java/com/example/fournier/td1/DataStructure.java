package com.example.fournier.td1;

public class DataStructure {

    private static DataStructure dataStructureInstance = null;

    public String name;

    private DataStructure(){
        name = "DefaultName";
    }

    public static DataStructure getInstance()
    {
        if (dataStructureInstance == null)
            dataStructureInstance = new DataStructure();

        return dataStructureInstance;
    }
}
