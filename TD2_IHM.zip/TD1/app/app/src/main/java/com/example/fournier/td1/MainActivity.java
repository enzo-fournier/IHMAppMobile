package com.example.fournier.td1;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Button;
import 	android.view.View;
import android.content.Intent;

public class MainActivity extends AppCompatActivity {

    TextView textViewName;
    Button buttonEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textViewName = findViewById(R.id.textViewName);
        buttonEdit = findViewById(R.id.buttonEdit);
        textViewName.setText(DataStructure.getInstance().name);
        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, EditActivity.class));
            }
        });
    }
}
