package com.example.fournier.td1;

import java.util.ArrayList;
import java.util.List;

public class DataStructure {

    private static DataStructure dataStructureInstance = null;

    private List<String> nameList;

    private DataStructure(){
        nameList = new ArrayList<>();
    }

    public static DataStructure getInstance()
    {
        if (dataStructureInstance == null)
            dataStructureInstance = new DataStructure();

        return dataStructureInstance;
    }

    public List<String> getNameList(){
        return nameList;
    }

    public void setNameList(List<String> nameList){
        this.nameList = nameList;
    }

    public void addName(String name){
        nameList.add(name);
    }
}
